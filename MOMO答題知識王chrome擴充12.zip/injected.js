// =========================================================
// momo 答題神隊友 - injected.js (在網頁主環境 MAIN 執行)
// 負責：
// 1. 極簡零副作用 App 檢測放行 (只放行 edmShare.isApp，絕不竄改 UA 與 Cookie)
// 2. 攔截 Momo 官方答題 API 的 fetch 與 XMLHttpRequest
// =========================================================

(function() {
  console.log('[momo 答題神隊友] 網路攔截核心與極簡放行引擎已就緒！');

  // =========================================================
  // 0. 極簡零副作用 App 檢測放行（最少篡改原則）
  // 僅劫持 edmShare.isApp 與 isInMomoApp，絕不竄改 User-Agent / Screen / 登入狀態
  // =========================================================
  (function initMinimalAppBypass() {
    let _edmShare = window.edmShare;
    try {
      Object.defineProperty(window, 'edmShare', {
        get: () => _edmShare,
        set: (val) => {
          _edmShare = val;
          if (_edmShare && typeof _edmShare === 'object') {
            _edmShare.isApp = () => true;
          }
        },
        configurable: true
      });
    } catch (e) {}

    try {
      Object.defineProperty(window, 'isInMomoApp', {
        get: () => () => true,
        set: () => {},
        configurable: true
      });
    } catch (e) {}

    const timer = setInterval(() => {
      if (window.edmShare && !window.edmShare.__isAppBypassed) {
        window.edmShare.isApp = () => true;
        window.edmShare.__isAppBypassed = true;
      }
      window.isInMomoApp = () => true;
    }, 50);
    setTimeout(() => clearInterval(timer), 8000);
  })();

  // =========================================================
  // 1. 滑鼠自動轉觸控事件模擬 (支援手機端點擊觸控)
  // =========================================================
  try {
    let isMouseDown = false;

    function buildTouch(e) {
      return new Touch({
        identifier: Date.now(),
        target: e.target,
        clientX: e.clientX,
        clientY: e.clientY,
        screenX: e.screenX,
        screenY: e.screenY,
        pageX: e.pageX,
        pageY: e.pageY
      });
    }

    function dispatchTouch(type, e, touch) {
      try {
        const touchEvent = new TouchEvent(type, {
          bubbles: true,
          cancelable: true,
          view: window,
          touches: type === 'touchend' ? [] : [touch],
          targetTouches: type === 'touchend' ? [] : [touch],
          changedTouches: [touch]
        });
        e.target.dispatchEvent(touchEvent);
      } catch (err) {}
    }

    window.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      if (e.target && e.target.closest && e.target.closest('.momo-ext-ui')) return;
      isMouseDown = true;
      dispatchTouch('touchstart', e, buildTouch(e));
    }, true);

    window.addEventListener('mousemove', (e) => {
      if (!isMouseDown) return;
      if (e.target && e.target.closest && e.target.closest('.momo-ext-ui')) return;
      dispatchTouch('touchmove', e, buildTouch(e));
    }, true);

    window.addEventListener('mouseup', (e) => {
      if (!isMouseDown) return;
      isMouseDown = false;
      dispatchTouch('touchend', e, buildTouch(e));
    }, true);
  } catch (e) {
    console.warn('[momo 答題神隊友] 觸控事件模擬初始化失敗:', e);
  }

  // =========================================================
  // 2. 攔截答題與結算 API & 全方位作答行為追蹤引擎
  // =========================================================
  let currentQuestion = null;
  let lastQuizUrl = '';
  let lastQuizHeaders = {};
  let lastSubmittedAnswerId = null;
  let lastSubmittedAnswerText = '';
  let lastSubmittedAnswerImage = '';

  // 全方位監聽使用者或自動程式在選項上的點擊與觸發 (備份 choiceId、文字、圖片)
  function trackClickedChoice(targetEl) {
    if (!targetEl) return;
    try {
      const el = targetEl.closest ? targetEl.closest('#KK_options li, .options li, #box_game li, [data-choice-id], [data-id], [data-uuid]') : targetEl;
      if (!el) return;

      const choiceId = el.dataset.choiceId || el.dataset.id || el.dataset.uuid || el.dataset.val ||
                       el.getAttribute('data-choice-id') || el.getAttribute('data-id') || el.getAttribute('data-uuid') || '';
      if (choiceId) {
        lastSubmittedAnswerId = choiceId;
      }

      const txtEl = el.querySelector ? (el.querySelector('.txt') || el.querySelector('span') || el) : el;
      const txt = txtEl ? txtEl.textContent.trim() : '';
      if (txt && txt !== '下一步' && txt !== '下一題') {
        lastSubmittedAnswerText = txt;
      }

      const imgEl = el.querySelector ? el.querySelector('img') : null;
      if (imgEl && imgEl.src) {
        lastSubmittedAnswerImage = imgEl.src;
      }
    } catch (err) {}
  }

  document.addEventListener('click', (e) => trackClickedChoice(e.target), true);
  document.addEventListener('pointerdown', (e) => trackClickedChoice(e.target), true);

  // 通用解析送出 Request 封包中的 answerId / 候選資料
  function extractSubmittedInfo(body, url) {
    let id = null;
    let txt = null;

    function checkObj(obj) {
      if (!obj || typeof obj !== 'object') return;
      id = id || obj.answerId || obj.choiceId || obj.choiceUuid || obj.selectedId || obj.optionId || obj.uuid || obj.ansId || obj.id;
      txt = txt || obj.answerText || obj.choiceText || obj.text || obj.val;
    }

    if (body) {
      if (typeof body === 'string') {
        try {
          const parsed = JSON.parse(body);
          checkObj(parsed);
        } catch (e) {
          try {
            const params = new URLSearchParams(body);
            id = id || params.get('answerId') || params.get('choiceId') || params.get('choiceUuid') || params.get('selectedId') || params.get('optionId') || params.get('uuid') || params.get('id');
            txt = txt || params.get('answerText') || params.get('choiceText') || params.get('text');
          } catch (e2) {}
        }
      } else if (typeof body === 'object') {
        if (typeof body.get === 'function') {
          id = id || body.get('answerId') || body.get('choiceId') || body.get('choiceUuid') || body.get('selectedId') || body.get('optionId') || body.get('uuid') || body.get('id');
          txt = txt || body.get('answerText') || body.get('choiceText') || body.get('text');
        } else {
          checkObj(body);
        }
      }
    }

    if (!id && url && url.includes('?')) {
      try {
        const u = new URL(url, window.location.origin);
        id = id || u.searchParams.get('answerId') || u.searchParams.get('choiceId') || u.searchParams.get('choiceUuid') || u.searchParams.get('selectedId') || u.searchParams.get('optionId');
      } catch (e) {}
    }

    return { id, txt };
  }

  function notifyExtension(type, payload) {
    try {
      window.postMessage({
        source: 'MOMO_QUIZ_INJECTED',
        type: type,
        data: payload
      }, '*');
    } catch (e) {
      console.warn('[momo 答題神隊友] postMessage 失敗:', e);
    }
  }

  function inspectPayload(url, json, submittedAnswerId) {
    if (!json || typeof json !== 'object') return;

    // 1. 偵測題目載入 (含 question 及 choices)
    const root = json.data || json;
    if (root.question && Array.isArray(root.choices) && root.choices.length > 0) {
      const qImg = (root.question && (root.question.image || root.question.img || root.question.imgUrl || root.question.pic)) 
        || root.questionImage || root.questionImg || root.img || root.pic || '';

      currentQuestion = {
        questionId: root.questionId || (root.question && root.question.uuid) || (root.question && root.question.id) || '',
        activityId: root.activityId || '',
        questionText: (typeof root.question === 'string') ? root.question : (root.question.text || root.question.title || ''),
        questionImage: qImg,
        choices: root.choices.map(c => ({
          choiceId: c.uuid || c.choiceId || c.id || '',
          text: (c.text || c.title || c.val || '').trim(),
          image: (c.image || c.img || c.imgUrl || '').trim()
        }))
      };
      console.log('[momo 答題神隊友] 偵測到題目載入:', currentQuestion.questionText, '題目圖片:', qImg);
      notifyExtension('QUESTION_LOADED', currentQuestion);
    }

    // 2. 偵測答題結算結果 (含 isCorrect 與 correctAnswerId，支援答對與答錯雙向全方位回報)
    const hasIsCorrect = ('isCorrect' in root) || ('is_correct' in root) || ('correct' in root) ||
                         ('isPass' in root) || ('result' in root) ||
                         ('success' in root && ('code' in root || 'data' in root));

    if (hasIsCorrect && currentQuestion) {
      let isCorrect = false;
      if ('isCorrect' in root) isCorrect = Boolean(root.isCorrect);
      else if ('is_correct' in root) isCorrect = Boolean(root.is_correct);
      else if ('correct' in root) isCorrect = Boolean(root.correct);
      else if ('isPass' in root) isCorrect = Boolean(root.isPass);
      else if ('success' in root) isCorrect = Boolean(root.success);
      else if (root.result === 'SUCCESS' || root.result === true || root.result === 'PASS') isCorrect = true;

      let correctId = root.correctAnswerId || root.correctChoiceId || root.correctId || root.answerId || '';
      const actualSubmittedId = submittedAnswerId || lastSubmittedAnswerId;
      const actualSubmittedText = lastSubmittedAnswerText;
      const actualSubmittedImage = lastSubmittedAnswerImage;

      // 核心關鍵修正：momo 官方結算 API 只回傳 { isCorrect: true }，若答對則正解就是剛才送出的 answerId！
      if (!correctId && isCorrect && actualSubmittedId) {
        correctId = actualSubmittedId;
      }

      console.log(`[momo 答題神隊友] 偵測到答題結算！是否答對: ${isCorrect}, 正解ID: ${correctId || '未知'}, 送出ID: ${actualSubmittedId || '無'}, 送出文字: ${actualSubmittedText || '無'}`);

      let correctChoice = null;
      let failedChoice = null;
      const wrongChoices = [];

      currentQuestion.choices.forEach(c => {
        const isMatchedChoice = (actualSubmittedId && c.choiceId === actualSubmittedId) ||
                                (actualSubmittedText && c.text && c.text.trim() === actualSubmittedText.trim()) ||
                                (actualSubmittedImage && c.image && actualSubmittedImage.includes(c.image.split('/').pop().split('?')[0]));

        if (correctId && c.choiceId === correctId) {
          correctChoice = c;
        } else if (isCorrect && !correctId && isMatchedChoice) {
          correctChoice = c;
        } else if (!isCorrect && isMatchedChoice) {
          failedChoice = c;
          wrongChoices.push(c);
        } else {
          wrongChoices.push(c);
        }
      });

      const reportData = {
        questionText: currentQuestion.questionText,
        questionImage: currentQuestion.questionImage,
        questionId: currentQuestion.questionId,
        activityId: currentQuestion.activityId,
        correctAnswerId: correctId || '',
        correctText: correctChoice ? correctChoice.text : '',
        correctImage: correctChoice ? correctChoice.image : '',
        failedChoiceId: failedChoice ? failedChoice.choiceId : (actualSubmittedId || ''),
        failedChoiceText: failedChoice ? failedChoice.text : (actualSubmittedText || ''),
        failedChoiceImage: failedChoice ? failedChoice.image : (actualSubmittedImage || ''),
        fallbackAttemptText: actualSubmittedText || '',
        fallbackAttemptImage: actualSubmittedImage || '',
        allChoices: currentQuestion.choices,
        wrongChoices: wrongChoices,
        isCorrect: isCorrect,
        timestamp: new Date().toISOString()
      };

      notifyExtension('ANSWER_REVEALED', reportData);
    }
  }

  // 攔截 window.fetch
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const url = (args[0] && typeof args[0] === 'string') ? args[0] : (args[0] && args[0].url ? args[0].url : '');
    let submittedAnswerId = null;

    // 攔截答題請求 Body 中的 answerId
    if (args[1] && args[1].body) {
      const info = extractSubmittedInfo(args[1].body, url);
      if (info.id) {
        submittedAnswerId = info.id;
        lastSubmittedAnswerId = info.id;
      }
      if (info.txt) {
        lastSubmittedAnswerText = info.txt;
      }
    }

    const response = await originalFetch.apply(this, args);
    try {
      if (url.includes('quiz') || url.includes('activity') || url.includes('game') || url.includes('mmp')) {
        lastQuizUrl = url;
        if (args[1] && args[1].headers) {
          lastQuizHeaders = args[1].headers;
        }
        const clone = response.clone();
        clone.json().then(data => {
          inspectPayload(url, data, submittedAnswerId || lastSubmittedAnswerId);
        }).catch(() => {});
      }
    } catch (err) {}
    return response;
  };

  // 攔截 XMLHttpRequest
  const originalXHR = window.XMLHttpRequest;
  function PatchedXHR() {
    const xhr = new originalXHR();
    let requestUrl = '';
    let xhrSubmittedAnswerId = null;

    const origOpen = xhr.open;
    xhr.open = function(method, url, ...rest) {
      requestUrl = url;
      return origOpen.apply(xhr, [method, url, ...rest]);
    };

    const origSend = xhr.send;
    xhr.send = function(body) {
      if (body && (requestUrl.includes('quiz') || requestUrl.includes('activity') || requestUrl.includes('game') || requestUrl.includes('mmp'))) {
        const info = extractSubmittedInfo(body, requestUrl);
        if (info.id) {
          xhrSubmittedAnswerId = info.id;
          lastSubmittedAnswerId = info.id;
        }
        if (info.txt) {
          lastSubmittedAnswerText = info.txt;
        }
      }
      return origSend.apply(xhr, arguments);
    };

    xhr.addEventListener('load', function() {
      try {
        if (requestUrl && (requestUrl.includes('quiz') || requestUrl.includes('activity') || requestUrl.includes('game') || requestUrl.includes('mmp'))) {
          lastQuizUrl = requestUrl;
          const contentType = xhr.getResponseHeader('content-type') || '';
          if (contentType.includes('json') || xhr.responseType === 'json' || typeof xhr.responseText === 'string') {
            const data = (xhr.responseType === 'json' && xhr.response) ? xhr.response : JSON.parse(xhr.responseText);
            inspectPayload(requestUrl, data, xhrSubmittedAnswerId || lastSubmittedAnswerId);
          }
        }
      } catch (e) {}
    });

    return xhr;
  }
  PatchedXHR.prototype = originalXHR.prototype;
  window.XMLHttpRequest = PatchedXHR;

})();
