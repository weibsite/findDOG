// =========================================================
// momo 答題神隊友 - popup.js
// =========================================================

document.addEventListener('DOMContentLoaded', () => {
  const bankStatusEl = document.getElementById('bankStatus');
  const bankCountEl = document.getElementById('bankCount');
  const contributedCountEl = document.getElementById('contributedCount');
  const btnStep1OpenPage = document.getElementById('btnStep1OpenPage');
  const btnStep2OpenWindow = document.getElementById('btnStep2OpenWindow');
  const btnSync = document.getElementById('btnSync');

  const MOMO_QUIZ_URL = 'https://www.momoshop.com.tw/edm/cmmedm.jsp?npn=1vEJn4Ny1oqt&n=1&viewport=mobile';

  // 1. 確保所有核心自動化功能預設恆為開啟
  chrome.storage.local.set({
    enableAppDisguise: true,
    enableMobileView: true,
    enableAutoClick: true,
    enableHighlight: true,
    enableAutoReport: true
  });

  // 2. 載入目前題庫與貢獻狀態
  chrome.storage.local.get({
    contributedCount: 0,
    cachedBank: [],
    bankUpdatedTime: ''
  }, (items) => {
    contributedCountEl.textContent = `${items.contributedCount} 題`;

    const count = (items.cachedBank && items.cachedBank.length) || 0;
    bankCountEl.textContent = `${count.toLocaleString()} 題`;

    if (count > 0) {
      bankStatusEl.textContent = `已連線 CDN (${items.bankUpdatedTime || '最新'})`;
      bankStatusEl.style.color = '#10b981';
    } else {
      bankStatusEl.textContent = '尚未同步';
      bankStatusEl.style.color = '#f59e0b';
    }
  });

  // 3. 步驟 1：開啟 / 前往正常手機網頁 (全版顯示活動主頁)
  btnStep1OpenPage.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const currentTab = tabs && tabs[0];
      if (currentTab && currentTab.url && currentTab.url.includes('momoshop.com.tw')) {
        let target = MOMO_QUIZ_URL;
        if (currentTab.url.includes('cmmedm.jsp') && currentTab.url.includes('npn=')) {
          try {
            const u = new URL(currentTab.url);
            u.searchParams.set('viewport', 'mobile');
            target = u.toString();
          } catch (e) {}
        }
        chrome.tabs.update(currentTab.id, { url: target });
      } else {
        chrome.tabs.create({ url: MOMO_QUIZ_URL });
      }
      window.close();
    });
  });

  // 4. 步驟 2：轉為獨立手機小視窗 (420x900)
  btnStep2OpenWindow.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const currentTab = tabs && tabs[0];
      let currentUrl = (currentTab && currentTab.url) || MOMO_QUIZ_URL;

      if (!currentUrl.includes('npn=')) {
        currentUrl = MOMO_QUIZ_URL;
      } else {
        try {
          const u = new URL(currentUrl);
          if (u.hostname.includes('momoshop.com.tw') && !u.searchParams.has('viewport')) {
            u.searchParams.set('viewport', 'mobile');
            currentUrl = u.toString();
          }
        } catch (e) {
          currentUrl = MOMO_QUIZ_URL;
        }
      }

      chrome.runtime.sendMessage({
        action: 'openMobileWindow',
        url: currentUrl
      });
      window.close();
    });
  });

  // 5. 手動立即檢查題庫更新 (委派 Service Worker 處理)
  btnSync.addEventListener('click', () => {
    btnSync.disabled = true;
    btnSync.textContent = '⏳ 同步中...';

    chrome.runtime.sendMessage({ action: 'syncBank' }, (response) => {
      if (response && response.questions && Array.isArray(response.questions)) {
        const count = response.questions.length;
        const nowStr = new Date().toLocaleTimeString();
        bankCountEl.textContent = `${count.toLocaleString()} 題`;
        bankStatusEl.textContent = `同步成功 (${nowStr})`;
        bankStatusEl.style.color = '#10b981';
        btnSync.textContent = '✅ 已是最新版本！';
        setTimeout(() => {
          btnSync.disabled = false;
          btnSync.textContent = '🔄 立即檢查題庫更新';
        }, 1500);
      } else {
        bankStatusEl.textContent = '同步失敗';
        bankStatusEl.style.color = '#ef4444';
        btnSync.textContent = '❌ 同步失敗，請稍候重試';
        setTimeout(() => {
          btnSync.disabled = false;
          btnSync.textContent = '🔄 立即檢查題庫更新';
        }, 2000);
      }
    });
  });
});
