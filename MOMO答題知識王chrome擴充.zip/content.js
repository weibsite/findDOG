// =========================================================
// momo 答題神隊友 - content.js (擴充套件內容腳本)
// 負責：題庫快取同步、頁面高亮輔助提示、自動將官方正解回傳伺服器
// =========================================================

(function() {
  console.log('[momo 答題神隊友] 內容腳本已載入！');

  const CDN_JSON_URL = 'https://finddog.online/momo_questions.json';
  const SERVER_AUTO_LEARN_URL = 'https://api.9ysong.shop/callback2/api/auto-learn';

  let localQuestions = [];
  let isQuestionsLoaded = false;
  let isMobileFrameEnabled = true;

  // =========================================================
  // 0. 自動切換手機版網址與強制解鎖手機遊戲區域
  // =========================================================
  function ensureMobileUrl() {
    try {
      if (window.location.hostname === 'www.momoshop.com.tw') {
        const url = new URL(window.location.href);
        if (!url.searchParams.has('viewport')) {
          const path = url.pathname.toLowerCase();
          if (path.includes('/edm/') || path.includes('/activity/') || path.includes('/mmp-') || path.includes('/main/') || path.includes('/goods/')) {
            url.searchParams.set('viewport', 'mobile');
            console.log('[momo 答題神隊友] 🔄 自動補全手機版參數:', url.toString());
            window.history.replaceState({}, '', url.toString());
          }
        }
      }
    } catch (e) {
      console.warn('[momo 答題神隊友] 檢查手機網址異常:', e);
    }
  }

  ensureMobileUrl();

  // 注入解鎖樣式：永久隱藏 PC 版「請使用手機開啟」阻擋層，直接解鎖真實遊戲內容
  const unlockStyle = document.createElement('style');
  unlockStyle.id = 'momo-ext-unlock-style';
  unlockStyle.textContent = `
    .Area_knowledgeKing.for_pc { display: none !important; }
    .Area_knowledgeKing.for_phone { display: block !important; }
  `;
  (document.head || document.documentElement).appendChild(unlockStyle);

  // =========================================================
  // 1. 自動手機排版與畫框模擬 (430px iPhone 16 Pro 規格)
  // =========================================================
  function applyMobileFrame(enable) {
    isMobileFrameEnabled = enable;
    let styleEl = document.getElementById('momo-ext-mobile-style');

    if (enable) {
      if (!styleEl) {
        styleEl = document.createElement('style');
        styleEl.id = 'momo-ext-mobile-style';
        styleEl.textContent = `
          html.momo-mobile-active {
            background-color: #121214 !important;
            display: flex !important;
            justify-content: center !important;
            min-height: 100vh !important;
            overflow-x: hidden !important;
          }
          body.momo-mobile-active {
            width: 430px !important;
            max-width: 430px !important;
            min-width: 430px !important;
            min-height: 100vh !important;
            margin: 0 auto !important;
            background-color: #ffffff !important;
            box-shadow: 0 0 50px rgba(0, 0, 0, 0.6) !important;
            position: relative !important;
            transform: translateZ(0) !important;
            overflow-x: hidden !important;
            transition: max-width 0.35s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.35s ease !important;
          }
          html.momo-mobile-active [style*="position: fixed"],
          html.momo-mobile-active [style*="position:fixed"] {
            max-width: 430px !important;
            left: 50% !important;
            transform: translateX(-50%) !important;
          }
        `;
        (document.head || document.documentElement).appendChild(styleEl);
      }

      document.documentElement.classList.add('momo-mobile-active');
      if (document.body) document.body.classList.add('momo-mobile-active');

      // 補上手機 Viewport meta
      if (!document.querySelector('meta[name="viewport"]')) {
        const meta = document.createElement('meta');
        meta.name = 'viewport';
        meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
        (document.head || document.documentElement).appendChild(meta);
      }
    } else {
      if (styleEl) styleEl.remove();
      document.documentElement.classList.remove('momo-mobile-active');
      if (document.body) document.body.classList.remove('momo-mobile-active');
    }
  }

  // 智慧排版過渡監聽：先全版顯示主頁說明，點擊開始挑戰時再自動縮小為手機答題畫面
  function initSmartLayoutWatcher() {
    document.addEventListener('click', (e) => {
      // 點擊「開始遊戲 / 開始挑戰」按鈕 -> 平滑切換為 430px 縮小手機畫框
      const playBtn = e.target && (e.target.id === 'btn_play' || e.target.closest('#btn_play'));
      if (playBtn) {
        console.log('[momo 答題神隊友] 🎮 點擊開始挑戰，自動切換至 430px 手機答題畫框！');
        applyMobileFrame(true);
      }

      // 點擊「回到主頁 / 返回」按鈕 -> 自動恢復全螢幕寬版顯示
      const backBtn = e.target && (e.target.closest('#KK_backBtn') || e.target.closest('#KK_goBackBtn'));
      if (backBtn) {
        console.log('[momo 答題神隊友] 🏠 返回活動主頁，自動恢復全螢幕寬版顯示！');
        applyMobileFrame(false);
      }
    }, true);

    // 監聽題目載入事件，確保答題時一定維持手機畫框
    window.addEventListener('message', (e) => {
      if (e.data && e.data.source === 'MOMO_QUIZ_INJECTED' && e.data.type === 'QUESTION_LOADED') {
        applyMobileFrame(true);
      }
    });

    // 動態觀察畫面元素：若當前正在答題頁 (#box_game)，自動維持手機模式
    const observer = new MutationObserver(() => {
      const boxGame = document.getElementById('box_game');
      if (boxGame && boxGame.style.display !== 'none' && !document.documentElement.classList.contains('momo-mobile-active')) {
        applyMobileFrame(true);
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class'] });
  }

  initSmartLayoutWatcher();

  // 1. 初始化設定與題庫快取
  chrome.storage.local.get({
    enableHighlight: true,
    enableAutoReport: true,
    enableMobileView: true,
    contributedCount: 0,
    cachedBank: null,
    bankLastModified: ''
  }, function(settings) {
    // 智慧判斷：若初始載入即在答題頁則套用手機框，若在活動主頁/起始頁(#box_start)則先保持寬版主頁顯示
    const isAlreadyInGame = document.getElementById('box_game') && document.getElementById('box_game').style.display !== 'none';
    if (settings.enableMobileView && isAlreadyInGame) {
      applyMobileFrame(true);
    }
    if (settings.cachedBank && Array.isArray(settings.cachedBank)) {
      localQuestions = settings.cachedBank;
      isQuestionsLoaded = true;
      console.log(`[momo 答題神隊友] 已載入快取題庫 ${localQuestions.length} 題`);
    }
    // 背景同步最新 CDN 題庫
    refreshBankFromCdn();
    // 渲染懸浮控制小按鈕
    createFloatingAssistantBadge();
  });

  function refreshBankFromCdn() {
    // 透過 Service Worker 代理請求，徹底解決網頁 CSP (Content Security Policy) 阻擋 fetch 的問題
    chrome.runtime.sendMessage({ action: 'syncBank' }, function(response) {
      if (chrome.runtime.lastError) {
        console.warn('[momo 答題神隊友] 同步題庫訊息發送異常:', chrome.runtime.lastError);
        return;
      }
      if (response && response.questions && Array.isArray(response.questions)) {
        localQuestions = response.questions;
        isQuestionsLoaded = true;
        console.log(`[momo 答題神隊友] 題庫已由 Service Worker 同步最新版，共 ${localQuestions.length} 題！`);
      }
    });
  }

  // 2. 監聽 injected.js 拋出的事件
  window.addEventListener('message', function(event) {
    if (event.source !== window || !event.data || event.data.source !== 'MOMO_QUIZ_INJECTED') {
      return;
    }

    const { type, data } = event.data;

    if (type === 'QUESTION_LOADED') {
      handleQuestionLoaded(data);
    } else if (type === 'ANSWER_REVEALED') {
      handleAnswerRevealed(data);
    }
  });

  // =========================================================
  // =========================================================
  // 處理 1：題目載入時，比對題庫、高亮提示並智慧自動答題
  // =========================================================
  function handleQuestionLoaded(qData) {
    chrome.storage.local.get({
      enableHighlight: true,
      enableAutoClick: true,
      autoClickDelay: 850
    }, function(cfg) {
      const qText = (qData.questionText || '').trim();
      if (!qText && !qData.questionImage) return;

      // 在題庫中搜尋匹配
      const matched = findMatchingQuestion(qText, qData.questionImage);
      let targetChoice = null;

      if (!matched) {
        console.log('[momo 答題神隊友] 本題為全新題目，題庫尚無紀錄。等待官方結算自動學習！');
        showFloatingNotice('💡 遇到全新題目！神隊友將在答題後自動學習官方正解！', '#0284c7');
        // 若啟用自動答題，新題目自動盲猜第一個選項以觸發官方回傳正解！
        if (qData.choices && qData.choices.length > 0) {
          targetChoice = qData.choices[0];
        }
      } else {
        console.log('[momo 答題神隊友] 命中題庫正解！', matched);
        showFloatingNotice(`🎯 神隊友找到正解：【${matched.ans}】`, '#10b981');

        if (cfg.enableHighlight) {
          highlightOptionOnPage(matched, qData.choices);
        }

        // 找出對應選項 choice 物件
        const ansTarget = (matched.ans || '').trim();
        const ansTargetImg = (matched.img_url || '').split('/').pop().split('?')[0];

        targetChoice = qData.choices.find(c => {
          if (ansTarget && c.text && (c.text === ansTarget || c.text.includes(ansTarget))) return true;
          if (ansTargetImg && c.image && c.image.includes(ansTargetImg)) return true;
          return false;
        }) || qData.choices[0];
      }

      // 執行「先畫面點擊，若無反應偷偷用 API 補刀」智慧引擎
      if (cfg.enableAutoClick && targetChoice) {
        executeAutoAnswer(matched, targetChoice, qData);
      }
    });
  }

  // =========================================================
  // 智慧自動答題引擎 (先畫面點擊，若無反應則偷偷用 API 補刀)
  // =========================================================
  function executeAutoAnswer(matched, targetChoice, qData) {
    chrome.storage.local.get({ enableAutoClick: true, autoClickDelay: 850 }, function(cfg) {
      if (!cfg.enableAutoClick || !targetChoice) return;

      const randomJitter = Math.floor(Math.random() * 350); // 隨機擾動 0~350ms，擬真人思考
      const delay = (cfg.autoClickDelay || 850) + randomJitter;

      console.log(`[momo 答題神隊友] 🤖 自動答題就緒，預計 ${delay}ms 後先嘗試畫面點擊...`);

      setTimeout(() => {
        let answerResolved = false;

        // 監聽答題是否已被頁面或官方接受
        const onAnswerHandled = (event) => {
          if (event.data && event.data.source === 'MOMO_QUIZ_INJECTED') {
            if (event.data.type === 'ANSWER_REVEALED' || event.data.type === 'QUESTION_LOADED') {
              answerResolved = true;
              window.removeEventListener('message', onAnswerHandled);
            }
          }
        };
        window.addEventListener('message', onAnswerHandled);

        // 1. 先執行方案 B：嘗試畫面擬真點擊
        const clicked = triggerOptionClick(targetChoice);
        if (clicked) {
          console.log('[momo 答題神隊友] 🎯 方案 B：已觸發選項擬真點擊，等待頁面反饋...');
        } else {
          console.warn('[momo 答題神隊友] ⚠️ 方案 B：畫面上未找到對應選項按鈕，將直接切換 API 補刀！');
        }

        // 2. 啟動 Watchdog 守門狗：若點擊 1.6 秒後依然無反應，偷偷用 API 補刀完成任務！
        setTimeout(() => {
          window.removeEventListener('message', onAnswerHandled);

          if (!answerResolved) {
            console.log('[momo 答題神隊友] 🕵️ 偵測到畫面點擊未獲回應，啟動 API 隱身補刀！');
            showFloatingNotice('⚡ 點擊未獲回應，神隊友已偷偷透過 API 完成答題！', '#f59e0b');

            window.postMessage({
              source: 'MOMO_QUIZ_BUDDY',
              type: 'STEALTH_API_SUBMIT',
              payload: {
                activityId: qData.activityId,
                questionId: qData.questionId,
                choiceId: targetChoice.choiceId,
                targetChoice: targetChoice
              }
            }, '*');
          }
        }, 1600);

      }, delay);
    });
  }

  function triggerOptionClick(targetChoice) {
    const el = findOptionElement(targetChoice);
    if (!el) return false;

    try {
      const rect = el.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;
      const opts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };

      // 擬真滑鼠 + 指針事件
      el.dispatchEvent(new MouseEvent('mouseover', opts));
      el.dispatchEvent(new PointerEvent('pointerdown', opts));
      el.dispatchEvent(new MouseEvent('mousedown', opts));

      // 原生觸控事件
      if (window.Touch && window.TouchEvent) {
        try {
          const touch = new Touch({ identifier: Date.now(), target: el, clientX: x, clientY: y });
          el.dispatchEvent(new TouchEvent('touchstart', { bubbles: true, cancelable: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
          el.dispatchEvent(new TouchEvent('touchend', { bubbles: true, cancelable: true, touches: [], targetTouches: [], changedTouches: [touch] }));
        } catch (e) {}
      }

      el.dispatchEvent(new PointerEvent('pointerup', opts));
      el.dispatchEvent(new MouseEvent('mouseup', opts));
      el.dispatchEvent(new MouseEvent('click', opts));
      el.click();

      // 支援 React / Next.js 內部 onClick 事件
      for (const key in el) {
        if (key.startsWith('__reactProps$') || key.startsWith('__reactEventHandlers$')) {
          const props = el[key];
          if (props && typeof props.onClick === 'function') {
            props.onClick({ preventDefault: () => {}, stopPropagation: () => {}, target: el, currentTarget: el });
          }
        }
      }

      // 視覺反饋按壓微縮放
      el.style.transform = 'scale(0.95)';
      setTimeout(() => { el.style.transform = ''; }, 150);

      return true;
    } catch (err) {
      console.warn('[momo 答題神隊友] triggerOptionClick 異常:', err);
      return false;
    }
  }

  function findOptionElement(targetChoice) {
    if (!targetChoice) return null;
    const targetText = (targetChoice.text || '').trim();
    const targetImg = (targetChoice.image || '').split('/').pop().split('?')[0];
    const targetId = targetChoice.choiceId;

    if (targetId) {
      const byAttr = document.querySelector(`[data-id="${targetId}"], [data-choice-id="${targetId}"], [id*="${targetId}"], [value="${targetId}"]`);
      if (byAttr) return byAttr;
    }

    const candidates = document.querySelectorAll('button, [role="button"], a, li, label, div');
    for (const el of candidates) {
      if (el.classList.contains('momo-ext-ui') || el.closest('.momo-ext-ui')) continue;
      if (el.offsetWidth > 420 || el.offsetHeight > 200) continue;

      const txt = el.textContent ? el.textContent.trim() : '';
      const imgEl = el.querySelector('img') || (el.tagName === 'IMG' ? el : null);

      if (targetText && txt && (txt === targetText || (txt.includes(targetText) && txt.length < targetText.length + 15))) {
        if (el.offsetWidth >= 30 && el.offsetHeight >= 20) return el;
      }

      if (targetImg && imgEl) {
        const src = imgEl.getAttribute('src') || '';
        if (src.includes(targetImg)) {
          return el;
        }
      }
    }
    return null;
  }

  function findMatchingQuestion(qText, qImg) {
    if (!localQuestions || localQuestions.length === 0) return null;

    const cleanQ = qText.replace(/[\s\-_,，.。?？!！]/g, '').toLowerCase();

    for (const item of localQuestions) {
      const itemQ = (item.q || '').replace(/[\s\-_,，.。?？!！]/g, '').toLowerCase();
      // 比對純文字相似
      if (cleanQ && itemQ && (cleanQ === itemQ || cleanQ.includes(itemQ) || itemQ.includes(cleanQ))) {
        return item;
      }
      // 比對題目圖片網址檔名
      if (qImg && item.img_url) {
        const qImgBase = qImg.split('/').pop().split('?')[0];
        const itemImgBase = item.img_url.split('/').pop().split('?')[0];
        if (qImgBase && itemImgBase && qImgBase === itemImgBase) {
          return item;
        }
      }
    }
    return null;
  }

  function highlightOptionOnPage(matchedItem, choices) {
    // 延遲 300ms 等待 DOM 渲染完畢
    setTimeout(() => {
      const ansTarget = (matchedItem.ans || '').trim();
      const ansTargetImg = (matchedItem.img_url || '').split('/').pop().split('?')[0];

      // 搜尋所有可能包含答案的選項元素
      const elements = document.querySelectorAll('button, div, li, span, a, label');
      elements.forEach(el => {
        const txt = el.textContent ? el.textContent.trim() : '';
        const hasImg = el.querySelector('img') || (el.tagName === 'IMG' ? el : null);

        let isMatch = false;
        if (ansTarget && txt && txt.includes(ansTarget) && txt.length < 50) {
          isMatch = true;
        }
        if (!isMatch && ansTargetImg && hasImg) {
          const src = hasImg.getAttribute('src') || '';
          if (src.includes(ansTargetImg)) {
            isMatch = true;
          }
        }

        if (isMatch && el.offsetWidth > 40 && el.offsetHeight > 20) {
          el.style.outline = '4px solid #10b981';
          el.style.boxShadow = '0 0 16px rgba(16, 185, 129, 0.6)';
          el.style.borderRadius = '8px';
          el.style.transition = 'all 0.3s ease';
        }
      });
    }, 400);
  }

  // =========================================================
  // 處理 2：答題結算時，自動回報官方正解給題庫伺服器 (協同進化)
  // =========================================================
  function handleAnswerRevealed(reportData) {
    chrome.storage.local.get({ enableAutoReport: true, contributedCount: 0 }, function(cfg) {
      if (!cfg.enableAutoReport) return;

      const qText = (reportData.questionText || '').trim();
      const ansText = (reportData.correctText || '').trim();
      const ansImage = (reportData.correctImage || '').trim();

      if (!qText && !reportData.questionImage) return;
      if (!ansText && !ansImage) return;

      const payload = {
        question: qText,
        questionImage: reportData.questionImage,
        answer: ansText || (ansImage ? '[圖片答案]' : ''),
        answerImage: ansImage,
        wrongOptions: reportData.wrongChoices.map(c => c.text).filter(Boolean),
        wrongImages: reportData.wrongChoices.map(c => c.image).filter(Boolean),
        allChoices: reportData.allChoices,
        isCorrect: reportData.isCorrect,
        submittedAt: new Date().toLocaleString(),
        client: 'momo-evolution-extension-v1'
      };

      console.log('[momo 答題神隊友] 正在委派 Service Worker 將官方正解回傳伺服器...', payload);

      chrome.runtime.sendMessage({
        action: 'autoLearn',
        payload: payload
      }, function() {
        const newCount = (cfg.contributedCount || 0) + 1;
        chrome.storage.local.set({ contributedCount: newCount });
        showFloatingNotice(`🎉 感謝貢獻！官方正解已同步全網題庫！(已累積貢獻 ${newCount} 題)`, '#d81e5b');
      });
    });
  }

  // =========================================================
  // 畫面懸浮提示框 (Toast Notification)
  // =========================================================
  function showFloatingNotice(text, bgColor = '#10b981') {
    let toast = document.getElementById('momo-quiz-buddy-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'momo-quiz-buddy-toast';
      toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 2147483647;
        background: ${bgColor};
        color: #ffffff;
        padding: 12px 18px;
        border-radius: 10px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 14px;
        font-weight: 600;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
        display: flex;
        align-items: center;
        gap: 8px;
        opacity: 0;
        transform: translateY(-10px);
        transition: all 0.3s ease;
        pointer-events: none;
      `;
      document.body.appendChild(toast);
    }

    toast.style.background = bgColor;
    toast.textContent = text;
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';

    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(-10px)';
    }, 4000);
  }

  // =========================================================
  // 網頁懸浮小精靈 (Floating Assistant Badge - 懶人手機小工具)
  // =========================================================
  function createFloatingAssistantBadge() {
    if (document.getElementById('momo-ext-floating-widget')) return;

    const widget = document.createElement('div');
    widget.id = 'momo-ext-floating-widget';
    widget.className = 'momo-ext-ui';
    widget.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 2147483646;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      user-select: none;
    `;

    widget.innerHTML = `
      <div id="momo-ext-pill" style="
        background: linear-gradient(135deg, #d81e5b, #e11d48);
        color: #ffffff;
        padding: 10px 14px;
        border-radius: 30px;
        box-shadow: 0 8px 20px rgba(216, 30, 91, 0.4);
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 13px;
        font-weight: bold;
        transition: all 0.2s ease;
      ">
        <span style="font-size: 16px;">📱</span>
        <span>神隊友手機助手</span>
      </div>

      <div id="momo-ext-menu" style="
        display: none;
        position: absolute;
        bottom: 50px;
        right: 0;
        width: 210px;
        background: #1e1e24;
        border: 1px solid rgba(255,255,255,0.15);
        border-radius: 12px;
        padding: 10px;
        box-shadow: 0 12px 30px rgba(0,0,0,0.5);
        color: #ffffff;
        font-size: 13px;
        backdrop-filter: blur(10px);
      ">
        <div style="font-weight: bold; margin-bottom: 8px; color: #fb7185; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 5px;">
          ⚙️ 兩步驟極簡操作
        </div>
        <button id="momo-ext-btn-go-main" style="
          width: 100%;
          background: #0284c7;
          color: white;
          border: none;
          padding: 8px 10px;
          border-radius: 8px;
          font-size: 12px;
          font-weight: bold;
          cursor: pointer;
          margin-bottom: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
        ">
          1️⃣ 開啟正常活動主頁
        </button>

        <button id="momo-ext-btn-popup-win" style="
          width: 100%;
          background: #7c3aed;
          color: white;
          border: none;
          padding: 8px 10px;
          border-radius: 8px;
          font-size: 12px;
          font-weight: bold;
          cursor: pointer;
          margin-bottom: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
        ">
          2️⃣ 轉為 420×900 手機視窗
        </button>

        <button id="momo-ext-btn-toggle-frame" style="
          width: 100%;
          background: #374151;
          color: white;
          border: none;
          padding: 8px 10px;
          border-radius: 8px;
          font-size: 12px;
          cursor: pointer;
          margin-bottom: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
        ">
          📱 切換 430px / 滿版
        </button>

        <div style="font-size: 11px; color: #9ca3af; text-align: center; margin-top: 4px;">
          題庫連線：${localQuestions.length} 題
        </div>
      </div>
    `;

    document.body.appendChild(widget);

    const pill = widget.querySelector('#momo-ext-pill');
    const menu = widget.querySelector('#momo-ext-menu');
    const btnGoMain = widget.querySelector('#momo-ext-btn-go-main');
    const btnPopupWin = widget.querySelector('#momo-ext-btn-popup-win');
    const btnToggleFrame = widget.querySelector('#momo-ext-btn-toggle-frame');

    pill.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.style.display = (menu.style.display === 'none' || !menu.style.display) ? 'block' : 'none';
    });

    document.addEventListener('click', (e) => {
      if (!widget.contains(e.target)) {
        menu.style.display = 'none';
      }
    });

    btnGoMain.addEventListener('click', () => {
      const MOMO_QUIZ_URL = 'https://www.momoshop.com.tw/edm/cmmedm.jsp?npn=1vEJn4Ny1oqt&n=1&viewport=mobile';
      window.location.href = MOMO_QUIZ_URL;
      menu.style.display = 'none';
    });

    btnPopupWin.addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'openMobileWindow', url: window.location.href });
      menu.style.display = 'none';
    });

    btnToggleFrame.addEventListener('click', () => {
      isMobileFrameEnabled = !isMobileFrameEnabled;
      chrome.storage.local.set({ enableMobileView: isMobileFrameEnabled });
      applyMobileFrame(isMobileFrameEnabled);
      showFloatingNotice(isMobileFrameEnabled ? '📱 已啟用 430px 手機模擬排版' : '🖥️ 已切換為瀏覽器全寬排版', '#3b82f6');
      menu.style.display = 'none';
    });
  }

  // 監聽外部設定變更
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
      if (changes.enableMobileView) {
        applyMobileFrame(changes.enableMobileView.newValue);
      }
    }
  });

})();
