<# :
@echo off
chcp 65001 >nul
title MOMO 答題神隊友 - 自動更新程式
cd /d "%~dp0"
echo.
echo ==========================================================
echo        MOMO 答題神隊友 - 一鍵自動更新程式
echo ==========================================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "iex ((Get-Content -LiteralPath '%~f0' -Raw -Encoding UTF8))"

echo.
pause
exit /b
#>

$ErrorActionPreference = 'Stop'
$dest = (Get-Location).Path

Write-Host ">>> 正在連接更新伺服器..." -ForegroundColor Cyan
Write-Host "    本機擴充路徑: $dest" -ForegroundColor DarkGray
Write-Host "    遠端更新來源: http://finddog.online/chrome/" -ForegroundColor DarkGray

# 確保支援 TLS 1.2 及 TLS 1.3
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13

# 預設的核心檔案清單
$defaultFiles = @(
    "manifest.json",
    "background.js",
    "content.js",
    "injected.js",
    "popup.html",
    "popup.css",
    "popup.js"
)

# 嘗試透過 GitHub API 動態取得 chrome 目錄下的最新檔案清單
$fileList = @()
try {
    $apiUrl = "https://api.github.com/repos/weibsite/findDOG/contents/chrome"
    $wcApi = New-Object System.Net.WebClient
    $wcApi.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) MomoExtensionUpdater/1.0")
    $jsonStr = $wcApi.DownloadString($apiUrl)
    $items = ConvertFrom-Json $jsonStr
    foreach ($item in $items) {
        if ($item.type -eq "file" -and $item.name -ne "no.txt") {
            $fileList += $item.name
        }
    }
} catch {}

if ($fileList.Count -eq 0) {
    $fileList = $defaultFiles
}

Write-Host "`n>>> 開始下載並覆蓋更新檔案 (共 $($fileList.Count) 個檔案)..." -ForegroundColor Cyan

$successCount = 0
$failCount = 0

for ($i = 0; $i -lt $fileList.Count; $i++) {
    $fn = $fileList[$i]
    $num = $i + 1
    Write-Host "    [$num/$($fileList.Count)] 更新 $fn ... " -NoNewline -ForegroundColor Gray

    $tempFile = Join-Path $dest "__tmp_$fn"
    $targetFile = Join-Path $dest $fn

    $downloadSuccess = $false
    $candidateUrls = @(
        "http://finddog.online/chrome/$fn",
        "https://finddog.online/chrome/$fn",
        "https://raw.githubusercontent.com/weibsite/findDOG/main/chrome/$fn"
    )

    foreach ($u in $candidateUrls) {
        try {
            if (Test-Path $tempFile) { Remove-Item $tempFile -Force -ErrorAction SilentlyContinue }
            $wc = New-Object System.Net.WebClient
            $wc.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) MomoExtensionUpdater/1.0")
            $wc.DownloadFile($u, $tempFile)

            if ((Test-Path $tempFile) -and ((Get-Item $tempFile).Length -gt 0)) {
                $downloadSuccess = $true
                break
            }
        } catch {
            # 備援：使用 curl.exe 下載
            try {
                & curl.exe -f -s -L -A "Mozilla/5.0" -o $tempFile "$u"
                if ((Test-Path $tempFile) -and ((Get-Item $tempFile).Length -gt 0)) {
                    $downloadSuccess = $true
                    break
                }
            } catch {}
        }
    }

    if ($downloadSuccess) {
        Copy-Item -Path $tempFile -Destination $targetFile -Force
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        $sizeStr = "{0:N0}" -f (Get-Item $targetFile).Length
        Write-Host "✅ 成功 ($sizeStr 位元組)" -ForegroundColor Green
        $successCount++
    } else {
        if (Test-Path $tempFile) { Remove-Item $tempFile -Force -ErrorAction SilentlyContinue }
        Write-Host "❌ 失敗" -ForegroundColor Red
        $failCount++
    }
}

if ($successCount -gt 0) {
    Write-Host "`n==========================================================" -ForegroundColor Green
    Write-Host "   🎉 更新完成！成功覆蓋 $successCount 個檔案！" -ForegroundColor Green
    Write-Host "==========================================================" -ForegroundColor Green
    Write-Host "👉 請回到 Chrome 瀏覽器 (網址輸入: chrome://extensions)" -ForegroundColor Yellow
    Write-Host "👉 在【momo 答題神隊友】卡片上點擊『重新載入 (🔄)』即可立即生效！`n" -ForegroundColor White
} else {
    Write-Host "`n❌ 更新失敗，無法自伺服器取得檔案，請確認網路連線正常。" -ForegroundColor Red
}
