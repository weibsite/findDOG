// =========================================================
// momo 答題神隊友 - injected.js (在網頁主環境 MAIN 執行)
// 負責：
// 1. DOM 層 navigator.userAgent 與 MOMOSHOP App 偽裝注入
// 2. 攔截 Momo 官方答題 API 的 fetch 與 XMLHttpRequest
// =========================================================

(function() {
  console.log('[momo 答題神隊友] 網路攔截與 MOMOSHOP 偽裝引擎已就緒！');

  // =========================================================
  // 1. DOM 層 MOMOSHOP 官方 App 指紋偽裝 (突破限 App 網頁防線)
  // =========================================================
  const MOMO_APP_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148[MOMOSHOP version:24.2.0;monet:;device:iOS;deviceID:C8A271B4-63F1-4F58-8C8B-8B2E98F12345;platform:1;userToken:;mg:0;MOMOSHOP] showTB=0";

  try {
    Object.defineProperty(navigator, 'userAgent', {
      get: () => MOMO_APP_UA,
      configurable: true
    });
    Object.defineProperty(navigator, 'appVersion', {
      get: () => MOMO_APP_UA,
      configurable: true
    });
    Object.defineProperty(navigator, 'platform', {
      get: () => 'iPhone',
      configurable: true
    });
    Object.defineProperty(navigator, 'vendor', {
      get: () => 'Apple Computer, Inc.',
      configurable: true
    });
    // 注入官方 App 識別標誌
    window.MOMOSHOP = true;
    window.isMomoApp = true;

    // 2. 螢幕尺寸偽裝 (突破手機尺寸檢測，模擬 iPhone 16 Pro)
    Object.defineProperty(screen, 'width', { get: () => 430, configurable: true });
    Object.defineProperty(screen, 'height', { get: () => 932, configurable: true });
    Object.defineProperty(screen, 'availWidth', { get: () => 430, configurable: true });
    Object.defineProperty(screen, 'availHeight', { get: () => 932, configurable: true });
    Object.defineProperty(screen, 'colorDepth', { get: () => 24, configurable: true });
    Object.defineProperty(screen, 'pixelDepth', { get: () => 24, configurable: true });
    Object.defineProperty(window, 'devicePixelRatio', { get: () => 3, configurable: true });

    // 3. 觸控支援 (Touch Support) 偽裝
    Object.defineProperty(navigator, 'maxTouchPoints', { get: () => 5, configurable: true });
    if (!('ontouchstart' in window)) {
      window.ontouchstart = null;
    }

    console.log('[momo 答題神隊友] ✅ 已成功偽裝為 MOMOSHOP 官方 App 環境與手機螢幕指紋！');
  } catch (e) {
    console.warn('[momo 答題神隊友] 偽裝 navigator/screen 失敗:', e);
  }

  // =========================================================
  // 2. 滑鼠自動轉觸控事件模擬 (免開 F12 也能直接操作手機端觸控按鈕)
  // =========================================================
  try {
    let isMouseDown = false;

    function buildTouch(e) {
      return new Touch({
        identifier: Date.now(),
        target: e.target,
        clientX: e.clientX,
        clientY: e.clientY,
        screenX: e.screenX,
        screenY: e.screenY,
        pageX: e.pageX,
        pageY: e.pageY
      });
    }

    function dispatchTouch(type, e, touch) {
      try {
        const touchEvent = new TouchEvent(type, {
          bubbles: true,
          cancelable: true,
          view: window,
          touches: type === 'touchend' ? [] : [touch],
          targetTouches: type === 'touchend' ? [] : [touch],
          changedTouches: [touch]
        });
        e.target.dispatchEvent(touchEvent);
      } catch (err) {}
    }

    window.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      if (e.target && e.target.closest && e.target.closest('.momo-ext-ui')) return;
      isMouseDown = true;
      dispatchTouch('touchstart', e, buildTouch(e));
    }, true);

    window.addEventListener('mousemove', (e) => {
      if (!isMouseDown) return;
      if (e.target && e.target.closest && e.target.closest('.momo-ext-ui')) return;
      dispatchTouch('touchmove', e, buildTouch(e));
    }, true);

    window.addEventListener('mouseup', (e) => {
      if (!isMouseDown) return;
      isMouseDown = false;
      dispatchTouch('touchend', e, buildTouch(e));
    }, true);
  } catch (e) {
    console.warn('[momo 答題神隊友] 觸控事件模擬初始化失敗:', e);
  }

  // =========================================================
  // 3. 攔截答題與結算 API & 隱身 API 補刀引擎
  // =========================================================
  let currentQuestion = null;
  let lastQuizUrl = '';
  let lastQuizHeaders = {};
  let lastSubmittedAnswerId = null;

  // 監聽使用者在畫面選項上的點擊 (備份最後點選之 choiceId)
  document.addEventListener('click', (e) => {
    try {
      const li = e.target.closest && e.target.closest('#KK_options li');
      if (li && li.dataset && li.dataset.choiceId) {
        lastSubmittedAnswerId = li.dataset.choiceId;
      }
    } catch (err) {}
  }, true);

  function notifyExtension(type, payload) {
    try {
      window.postMessage({
        source: 'MOMO_QUIZ_INJECTED',
        type: type,
        data: payload
      }, '*');
    } catch (e) {
      console.warn('[momo 答題神隊友] postMessage 失敗:', e);
    }
  }

  function inspectPayload(url, json, submittedAnswerId) {
    if (!json || typeof json !== 'object') return;

    // 1. 偵測題目載入 (含 question 及 choices)
    const root = json.data || json;
    if (root.question && Array.isArray(root.choices) && root.choices.length > 0) {
      const qImg = (root.question && (root.question.image || root.question.img || root.question.imgUrl || root.question.pic)) 
        || root.questionImage || root.questionImg || root.img || root.pic || '';

      currentQuestion = {
        questionId: root.questionId || (root.question && root.question.uuid) || (root.question && root.question.id) || '',
        activityId: root.activityId || '',
        questionText: (typeof root.question === 'string') ? root.question : (root.question.text || root.question.title || ''),
        questionImage: qImg,
        choices: root.choices.map(c => ({
          choiceId: c.uuid || c.choiceId || c.id || '',
          text: (c.text || c.title || c.val || '').trim(),
          image: (c.image || c.img || c.imgUrl || '').trim()
        }))
      };
      console.log('[momo 答題神隊友] 偵測到題目載入:', currentQuestion.questionText, '題目圖片:', qImg);
      notifyExtension('QUESTION_LOADED', currentQuestion);
    }

    // 2. 偵測答題結算結果 (含 isCorrect 與 correctAnswerId)
    const hasIsCorrect = ('isCorrect' in root) || ('is_correct' in root) || ('correct' in root);
    const isCorrect = Boolean(root.isCorrect || root.is_correct || root.correct);
    let correctId = root.correctAnswerId || root.correctChoiceId || root.correctId || root.answerId;

    // 核心關鍵修正：momo 官方結算 API 只回傳 { isCorrect: true }，若答對則正解就是剛才送出的 answerId！
    if (!correctId && isCorrect && (submittedAnswerId || lastSubmittedAnswerId)) {
      correctId = submittedAnswerId || lastSubmittedAnswerId;
    }

    if (correctId !== undefined && currentQuestion) {
      console.log('[momo 答題神隊友] 偵測到答題結算！官方正解 ID:', correctId, '是否答對:', isCorrect);

      let correctChoice = null;
      const wrongChoices = [];

      currentQuestion.choices.forEach(c => {
        if (c.choiceId === correctId) {
          correctChoice = c;
        } else {
          wrongChoices.push(c);
        }
      });

      const reportData = {
        questionText: currentQuestion.questionText,
        questionImage: currentQuestion.questionImage,
        questionId: currentQuestion.questionId,
        activityId: currentQuestion.activityId,
        correctAnswerId: correctId,
        correctText: correctChoice ? correctChoice.text : '',
        correctImage: correctChoice ? correctChoice.image : '',
        allChoices: currentQuestion.choices,
        wrongChoices: wrongChoices,
        isCorrect: isCorrect,
        timestamp: new Date().toISOString()
      };

      notifyExtension('ANSWER_REVEALED', reportData);
    }
  }

  // 攔截 window.fetch
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const url = (args[0] && typeof args[0] === 'string') ? args[0] : (args[0] && args[0].url ? args[0].url : '');
    let submittedAnswerId = null;

    // 攔截答題請求 Body 中的 answerId
    if (args[1] && args[1].body) {
      try {
        const reqBody = typeof args[1].body === 'string' ? JSON.parse(args[1].body) : args[1].body;
        if (reqBody && (reqBody.answerId || reqBody.choiceId)) {
          submittedAnswerId = reqBody.answerId || reqBody.choiceId;
          lastSubmittedAnswerId = submittedAnswerId;
        }
      } catch (e) {}
    }

    const response = await originalFetch.apply(this, args);
    try {
      if (url.includes('quiz') || url.includes('activity') || url.includes('game') || url.includes('mmp')) {
        lastQuizUrl = url;
        if (args[1] && args[1].headers) {
          lastQuizHeaders = args[1].headers;
        }
        const clone = response.clone();
        clone.json().then(data => {
          inspectPayload(url, data, submittedAnswerId || lastSubmittedAnswerId);
        }).catch(() => {});
      }
    } catch (err) {}
    return response;
  };

  // 攔截 XMLHttpRequest
  const originalXHR = window.XMLHttpRequest;
  function PatchedXHR() {
    const xhr = new originalXHR();
    let requestUrl = '';
    let xhrSubmittedAnswerId = null;

    const origOpen = xhr.open;
    xhr.open = function(method, url, ...rest) {
      requestUrl = url;
      return origOpen.apply(xhr, [method, url, ...rest]);
    };

    const origSend = xhr.send;
    xhr.send = function(body) {
      if (body && (requestUrl.includes('quiz') || requestUrl.includes('activity') || requestUrl.includes('game') || requestUrl.includes('mmp'))) {
        try {
          const reqBody = typeof body === 'string' ? JSON.parse(body) : body;
          if (reqBody && (reqBody.answerId || reqBody.choiceId)) {
            xhrSubmittedAnswerId = reqBody.answerId || reqBody.choiceId;
            lastSubmittedAnswerId = xhrSubmittedAnswerId;
          }
        } catch (e) {}
      }
      return origSend.apply(xhr, arguments);
    };

    xhr.addEventListener('load', function() {
      try {
        if (requestUrl && (requestUrl.includes('quiz') || requestUrl.includes('activity') || requestUrl.includes('game') || requestUrl.includes('mmp'))) {
          lastQuizUrl = requestUrl;
          const contentType = xhr.getResponseHeader('content-type') || '';
          if (contentType.includes('json') || xhr.responseType === 'json' || typeof xhr.responseText === 'string') {
            const data = (xhr.responseType === 'json' && xhr.response) ? xhr.response : JSON.parse(xhr.responseText);
            inspectPayload(requestUrl, data, xhrSubmittedAnswerId || lastSubmittedAnswerId);
          }
        }
      } catch (e) {}
    });

    return xhr;
  }
  PatchedXHR.prototype = originalXHR.prototype;
  window.XMLHttpRequest = PatchedXHR;

})();
