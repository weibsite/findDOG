// =========================================================
// momo 答題神隊友 - popup.js
// =========================================================

document.addEventListener('DOMContentLoaded', () => {
  const bankStatusEl = document.getElementById('bankStatus');
  const bankCountEl = document.getElementById('bankCount');
  const contributedCountEl = document.getElementById('contributedCount');
  const btnStep1OpenPage = document.getElementById('btnStep1OpenPage');
  const btnStep2OpenWindow = document.getElementById('btnStep2OpenWindow');
  const btnSync = document.getElementById('btnSync');

  const MOMO_QUIZ_URL = 'https://www.momoshop.com.tw/edm/cmmedm.jsp?npn=1vEJn4Ny1oqt&n=1&viewport=mobile';

  const toggleAutoClick = document.getElementById('toggleAutoClick');
  const autoClickDesc = document.getElementById('autoClickDesc');
  const toggleAutoNext = document.getElementById('toggleAutoNext');
  const autoNextDesc = document.getElementById('autoNextDesc');

  function updateAutoClickDesc(enabled) {
    if (!autoClickDesc) return;
    if (enabled) {
      autoClickDesc.textContent = '🟢 已開啟：找到正解時自動勾選目標選項';
      autoClickDesc.style.color = '#10b981';
    } else {
      autoClickDesc.textContent = '🟠 已關閉：只標記高亮正解，不自動點選';
      autoClickDesc.style.color = '#f59e0b';
    }
  }

  function updateAutoNextDesc(enabled) {
    if (!autoNextDesc) return;
    if (enabled) {
      autoNextDesc.textContent = '🟢 已開啟：答對後自動點擊按鈕進入下一題';
      autoNextDesc.style.color = '#10b981';
    } else {
      autoNextDesc.textContent = '⚪ 已關閉：答對後停留畫面，手動點擊下一步';
      autoNextDesc.style.color = '#94a3b8';
    }
  }

  // 1. 讀取並維持使用者開關設定
  chrome.storage.local.get({
    enableAppDisguise: true,
    enableMobileView: true,
    enableAutoClick: true,
    enableAutoNext: true,
    enableHighlight: true,
    enableAutoReport: true
  }, (cfg) => {
    if (toggleAutoClick) {
      toggleAutoClick.checked = cfg.enableAutoClick;
      updateAutoClickDesc(cfg.enableAutoClick);

      toggleAutoClick.addEventListener('change', () => {
        const isEnabled = toggleAutoClick.checked;
        chrome.storage.local.set({ enableAutoClick: isEnabled });
        updateAutoClickDesc(isEnabled);
      });
    }

    if (toggleAutoNext) {
      toggleAutoNext.checked = cfg.enableAutoNext !== false;
      updateAutoNextDesc(cfg.enableAutoNext !== false);

      toggleAutoNext.addEventListener('change', () => {
        const isEnabled = toggleAutoNext.checked;
        chrome.storage.local.set({ enableAutoNext: isEnabled });
        updateAutoNextDesc(isEnabled);
      });
    }
  });

  // 2. 載入目前題庫與貢獻狀態
  chrome.storage.local.get({
    contributedCount: 0,
    cachedBank: [],
    bankUpdatedTime: ''
  }, (items) => {
    contributedCountEl.textContent = `${items.contributedCount} 題`;

    const count = (items.cachedBank && items.cachedBank.length) || 0;
    bankCountEl.textContent = `${count.toLocaleString()} 題`;

    if (count > 0) {
      bankStatusEl.textContent = `已連線 CDN (${items.bankUpdatedTime || '最新'})`;
      bankStatusEl.style.color = '#10b981';
    } else {
      bankStatusEl.textContent = '尚未同步';
      bankStatusEl.style.color = '#f59e0b';
    }
  });

  // 3. 步驟 1：開啟 / 前往正常手機網頁 (全版顯示活動主頁)
  btnStep1OpenPage.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const currentTab = tabs && tabs[0];
      if (currentTab && currentTab.url && currentTab.url.includes('momoshop.com.tw')) {
        let target = MOMO_QUIZ_URL;
        if (currentTab.url.includes('cmmedm.jsp') && currentTab.url.includes('npn=')) {
          try {
            const u = new URL(currentTab.url);
            u.searchParams.set('viewport', 'mobile');
            target = u.toString();
          } catch (e) {}
        }
        chrome.tabs.update(currentTab.id, { url: target });
      } else {
        chrome.tabs.create({ url: MOMO_QUIZ_URL });
      }
      window.close();
    });
  });

  // 4. 步驟 2：轉為獨立手機小視窗 (420x900)
  btnStep2OpenWindow.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const currentTab = tabs && tabs[0];
      let currentUrl = (currentTab && currentTab.url) || MOMO_QUIZ_URL;

      if (!currentUrl.includes('npn=')) {
        currentUrl = MOMO_QUIZ_URL;
      } else {
        try {
          const u = new URL(currentUrl);
          if (u.hostname.includes('momoshop.com.tw') && !u.searchParams.has('viewport')) {
            u.searchParams.set('viewport', 'mobile');
            currentUrl = u.toString();
          }
        } catch (e) {
          currentUrl = MOMO_QUIZ_URL;
        }
      }

      chrome.runtime.sendMessage({
        action: 'openMobileWindow',
        url: currentUrl
      });
      window.close();
    });
  });

  // 5. 手動立即檢查題庫更新 (委派 Service Worker 處理)
  btnSync.addEventListener('click', () => {
    btnSync.disabled = true;
    btnSync.textContent = '⏳ 同步中...';

    chrome.runtime.sendMessage({ action: 'syncBank' }, (response) => {
      if (response && response.questions && Array.isArray(response.questions)) {
        const count = response.questions.length;
        const nowStr = new Date().toLocaleTimeString();
        bankCountEl.textContent = `${count.toLocaleString()} 題`;
        bankStatusEl.textContent = `同步成功 (${nowStr})`;
        bankStatusEl.style.color = '#10b981';
        btnSync.textContent = '✅ 已是最新版本！';
        setTimeout(() => {
          btnSync.disabled = false;
          btnSync.textContent = '🔄 立即檢查題庫更新';
        }, 1500);
      } else {
        bankStatusEl.textContent = '同步失敗';
        bankStatusEl.style.color = '#ef4444';
        btnSync.textContent = '❌ 同步失敗，請稍候重試';
        setTimeout(() => {
          btnSync.disabled = false;
          btnSync.textContent = '🔄 立即檢查題庫更新';
        }, 2000);
      }
    });
  });
});
