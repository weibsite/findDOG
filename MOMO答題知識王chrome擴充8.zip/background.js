// =========================================================
// momo 答題神隊友 - background.js (Service Worker)
// 負責：題庫快取同步、官方正解伺服器回傳、獨立手機視窗開啟
// 維持瀏覽器原生 User-Agent 與網路環境，確保 BitBrowser 登入狀態不丟失
// =========================================================

// CDN 題庫與伺服器常數 (由 Service Worker 發送，突破網頁端 CSP 限制)
const CDN_JSON_URL = 'https://finddog.online/momo_questions.json';
const SERVER_AUTO_LEARN_URL = 'https://api.9ysong.shop/callback2/api/auto-learn';

async function fetchCdnBank() {
  try {
    const res = await fetch(`${CDN_JSON_URL}?t=${Date.now()}`);
    if (res.ok) {
      const data = await res.json();
      if (data && data.questions && Array.isArray(data.questions)) {
        chrome.storage.local.set({
          cachedBank: data.questions,
          bankLastModified: data.last_modified || '',
          bankUpdatedTime: new Date().toLocaleTimeString()
        });
        console.log(`[momo 答題神隊友 SW] 題庫已由 Service Worker 成功同步，共 ${data.questions.length} 題！`);
        return data.questions;
      }
    }
  } catch (err) {
    console.warn('[momo 答題神隊友 SW] 同步 CDN 題庫失敗:', err);
  }
  return null;
}

async function reportAutoLearn(payload) {
  try {
    const res = await fetch(SERVER_AUTO_LEARN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      console.log('[momo 答題神隊友 SW] 官方正解已由 Service Worker 成功送達！');
    }
  } catch (err) {
    console.warn('[momo 答題神隊友 SW] 自動學習上傳失敗:', err);
  }
}

// 清除舊版本殘留的 declarativeNetRequest 偽裝規則，徹底還原原生瀏覽器環境
async function clearLegacyDisguiseRules() {
  try {
    if (chrome.declarativeNetRequest && chrome.declarativeNetRequest.updateDynamicRules) {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [1001]
      });
      console.log('[momo 答題神隊友 SW] 已確認清除舊版 App UA 偽裝規則，維持瀏覽器原生登入狀態。');
    }
  } catch (e) {
    // 忽略錯誤
  }
}

// 監聽擴充套件安裝與啟動事件
chrome.runtime.onInstalled.addListener(() => {
  clearLegacyDisguiseRules();
  fetchCdnBank();
});

chrome.runtime.onStartup.addListener(() => {
  clearLegacyDisguiseRules();
  fetchCdnBank();
});

// 監聽來自 content.js 或 popup.js 的請求 (突破網頁端 CSP 限制)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // 1. 同步 CDN 題庫
  if (request.action === 'syncBank') {
    fetchCdnBank().then(questions => {
      sendResponse({ status: 'ok', questions: questions });
    });
    return true; // 異步回應
  }

  // 2. 自動回報官方正解至伺服器
  if (request.action === 'autoLearn') {
    reportAutoLearn(request.payload);
    sendResponse({ status: 'ok' });
    return true;
  }

  // 3. 開啟手機獨立視窗請求 (免 F12，獨立 420x900 小視窗)
  if (request.action === 'openMobileWindow') {
    const MOMO_QUIZ_URL = 'https://www.momoshop.com.tw/edm/cmmedm.jsp?npn=1vEJn4Ny1oqt&n=1&viewport=mobile';
    let targetUrl = request.url;
    if (!targetUrl || targetUrl.startsWith('chrome://') || targetUrl.startsWith('edge://') || !targetUrl.includes('npn=')) {
      targetUrl = MOMO_QUIZ_URL;
    } else {
      // 確保帶有 viewport=mobile
      try {
        const u = new URL(targetUrl);
        if (u.hostname.includes('momoshop.com.tw') && !u.searchParams.has('viewport')) {
          u.searchParams.set('viewport', 'mobile');
          targetUrl = u.toString();
        }
      } catch (e) {}
    }

    chrome.windows.create({
      url: targetUrl,
      type: 'popup',
      width: 420,
      height: 900,
      focused: true
    }, (createdWin) => {
      sendResponse({ status: 'ok', windowId: createdWin ? createdWin.id : null });
    });
    return true; // 異步回應
  }

  // 4. Cookie 槽位管理功能 (1~9 槽位備份與還原)
  if (request.action === 'saveCookiesToSlot') {
    saveCookiesToSlot(request.slot).then(res => sendResponse(res));
    return true;
  }

  if (request.action === 'loadCookiesFromSlot') {
    loadCookiesFromSlot(request.slot).then(res => sendResponse(res));
    return true;
  }

  if (request.action === 'getCookieSlotsInfo') {
    getCookieSlotsInfo().then(res => sendResponse(res));
    return true;
  }
});

// =========================================================
// Cookie 槽位核心操作 (讀取、儲存、清除)
// =========================================================
function getCookieUrl(c) {
  let domain = c.domain || 'www.momoshop.com.tw';
  if (domain.startsWith('.')) {
    domain = domain.slice(1);
  }
  const protocol = c.secure ? 'https:' : 'http:';
  const path = c.path || '/';
  return `${protocol}//${domain}${path}`;
}

async function getAllMomoCookies() {
  const domains = ['momoshop.com.tw', '.momoshop.com.tw', 'www.momoshop.com.tw', 'event.momoshop.com.tw'];
  const allCookies = [];
  const seen = new Set();
  for (const d of domains) {
    try {
      const list = await chrome.cookies.getAll({ domain: d });
      for (const c of list) {
        const key = `${c.domain}|${c.path}|${c.name}`;
        if (!seen.has(key)) {
          seen.add(key);
          allCookies.push(c);
        }
      }
    } catch (e) {}
  }
  return allCookies;
}

async function clearAllMomoCookies() {
  const current = await getAllMomoCookies();
  for (const c of current) {
    try {
      await chrome.cookies.remove({
        url: getCookieUrl(c),
        name: c.name,
        storeId: c.storeId
      });
    } catch (e) {}
  }
  return current.length;
}

async function saveCookiesToSlot(slot) {
  const cookies = await getAllMomoCookies();
  const meta = {
    savedAt: new Date().toLocaleString(),
    timestamp: Date.now(),
    count: cookies.length
  };
  await chrome.storage.local.set({
    [`momo_cookie_slot_${slot}`]: cookies,
    [`momo_cookie_meta_${slot}`]: meta
  });
  return { success: true, slot: slot, count: cookies.length, meta: meta };
}

async function loadCookiesFromSlot(slot) {
  const key = `momo_cookie_slot_${slot}`;
  const data = await chrome.storage.local.get([key]);
  const targetCookies = data[key];

  // 清除現有的所有 MOMO cookies
  await clearAllMomoCookies();

  if (targetCookies && Array.isArray(targetCookies) && targetCookies.length > 0) {
    let restoredCount = 0;
    for (const c of targetCookies) {
      try {
        const details = {
          url: getCookieUrl(c),
          name: c.name,
          value: c.value,
          path: c.path || '/',
          secure: Boolean(c.secure),
          httpOnly: Boolean(c.httpOnly),
          sameSite: c.sameSite || 'unspecified',
          storeId: c.storeId
        };
        if (c.domain && !c.hostOnly) {
          details.domain = c.domain;
        }
        if (c.expirationDate) {
          details.expirationDate = c.expirationDate;
        }
        await chrome.cookies.set(details);
        restoredCount++;
      } catch (e) {
        console.warn('[SW Cookie] 寫入 cookie 失敗:', c.name, e);
      }
    }
    return { success: true, action: 'restored', slot: slot, count: restoredCount };
  } else {
    // 空槽位：代表初始狀態 (已全數清除)
    return { success: true, action: 'cleared', slot: slot, count: 0 };
  }
}

async function getCookieSlotsInfo() {
  const keys = [];
  for (let i = 1; i <= 9; i++) {
    keys.push(`momo_cookie_meta_${i}`);
  }
  const data = await chrome.storage.local.get(keys);
  const slots = {};
  for (let i = 1; i <= 9; i++) {
    slots[i] = data[`momo_cookie_meta_${i}`] || null;
  }
  return slots;
}
