// =========================================================
// momo 答題神隊友 - background.js (Service Worker)
// 負責：透過 declarativeNetRequest 動態偽裝 MOMOSHOP App 請求標頭
// =========================================================

const RULE_ID_MOMO_UA = 1001;

// 官方 iOS App User-Agent 樣板 (自逆向 test.exe 提取之真機指紋)
const MOMO_APP_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148[MOMOSHOP version:24.2.0;monet:;device:iOS;deviceID:C8A271B4-63F1-4F58-8C8B-8B2E98F12345;platform:1;userToken:;mg:0;MOMOSHOP] showTB=0";

// CDN 題庫與伺服器常數 (由 Service Worker 發送，突破網頁端 CSP 限制)
const CDN_JSON_URL = 'https://finddog.online/momo_questions.json';
const SERVER_AUTO_LEARN_URL = 'https://api.9ysong.shop/callback2/api/auto-learn';

async function fetchCdnBank() {
  try {
    const res = await fetch(`${CDN_JSON_URL}?t=${Date.now()}`);
    if (res.ok) {
      const data = await res.json();
      if (data && data.questions && Array.isArray(data.questions)) {
        chrome.storage.local.set({
          cachedBank: data.questions,
          bankLastModified: data.last_modified || '',
          bankUpdatedTime: new Date().toLocaleTimeString()
        });
        console.log(`[momo 答題神隊友 SW] 題庫已由 Service Worker 成功同步，共 ${data.questions.length} 題！`);
        return data.questions;
      }
    }
  } catch (err) {
    console.warn('[momo 答題神隊友 SW] 同步 CDN 題庫失敗:', err);
  }
  return null;
}

async function reportAutoLearn(payload) {
  try {
    const res = await fetch(SERVER_AUTO_LEARN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      console.log('[momo 答題神隊友 SW] 官方正解已由 Service Worker 成功送達！');
    }
  } catch (err) {
    console.warn('[momo 答題神隊友 SW] 自動學習上傳失敗:', err);
  }
}

async function applyAppDisguise(enable) {
  try {
    if (enable) {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [RULE_ID_MOMO_UA],
        addRules: [
          {
            id: RULE_ID_MOMO_UA,
            priority: 1,
            action: {
              type: "modifyHeaders",
              requestHeaders: [
                {
                  header: "User-Agent",
                  operation: "set",
                  value: MOMO_APP_UA
                }
              ]
            },
            condition: {
              urlFilter: "||momoshop.com.tw",
              resourceTypes: [
                "main_frame",
                "sub_frame",
                "stylesheet",
                "script",
                "image",
                "font",
                "object",
                "xmlhttprequest",
                "ping",
                "csp_report",
                "media",
                "websocket",
                "other"
              ]
            }
          }
        ]
      });
      console.log("[momo 答題神隊友] ✅ 網路層 MOMOSHOP App 偽裝已啟用！");
    } else {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [RULE_ID_MOMO_UA]
      });
      console.log("[momo 答題神隊友] ⏹️ 網路層 MOMOSHOP App 偽裝已關閉。");
    }
  } catch (err) {
    console.error("[momo 答題神隊友] 設定 declarativeNetRequest 失敗:", err);
  }
}

// 監聽擴充套件安裝與啟動事件
chrome.runtime.onInstalled.addListener(() => {
  fetchCdnBank();
  chrome.storage.local.get({ enableAppDisguise: true }, (items) => {
    applyAppDisguise(items.enableAppDisguise);
  });
});

chrome.runtime.onStartup.addListener(() => {
  fetchCdnBank();
  chrome.storage.local.get({ enableAppDisguise: true }, (items) => {
    applyAppDisguise(items.enableAppDisguise);
  });
});

// 監聽 Popup 開關設定變更
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes.enableAppDisguise) {
    applyAppDisguise(changes.enableAppDisguise.newValue);
  }
});

// 監聽來自 content.js 或 popup.js 的請求 (突破網頁端 CSP 限制)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // 1. 同步 CDN 題庫
  if (request.action === 'syncBank') {
    fetchCdnBank().then(questions => {
      sendResponse({ status: 'ok', questions: questions });
    });
    return true; // 異步回應
  }

  // 2. 自動回報官方正解至伺服器
  if (request.action === 'autoLearn') {
    reportAutoLearn(request.payload);
    sendResponse({ status: 'ok' });
    return true;
  }

  // 3. 開啟手機獨立視窗請求 (免 F12，獨立 420x900 App 小視窗)
  if (request.action === 'openMobileWindow') {
    const MOMO_QUIZ_URL = 'https://www.momoshop.com.tw/edm/cmmedm.jsp?npn=1vEJn4Ny1oqt&n=1&viewport=mobile';
    let targetUrl = request.url;
    if (!targetUrl || targetUrl.startsWith('chrome://') || targetUrl.startsWith('edge://') || !targetUrl.includes('npn=')) {
      targetUrl = MOMO_QUIZ_URL;
    } else {
      // 確保帶有 viewport=mobile
      try {
        const u = new URL(targetUrl);
        if (u.hostname.includes('momoshop.com.tw') && !u.searchParams.has('viewport')) {
          u.searchParams.set('viewport', 'mobile');
          targetUrl = u.toString();
        }
      } catch (e) {}
    }

    chrome.windows.create({
      url: targetUrl,
      type: 'popup',
      width: 420,
      height: 900,
      focused: true
    }, (createdWin) => {
      sendResponse({ status: 'ok', windowId: createdWin ? createdWin.id : null });
    });
    return true; // 異步回應
  }
});
